<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:dt="uuid:C2F41010-65B3-11d1-A29F-00AA00C14882" xmlns="http://www.w3.org/TR/REC-html40">

<head>
    <meta http-equiv=Content-Type content="text/html; charset=utf-8">
    <meta name=ProgId content=Word.Document>
    <meta name=Generator content="Microsoft Word 14">
    <meta name=Originator content="Microsoft Word 14">
    <title></title>


    <style>
        @font-face {
            font-family: "Times New Roman";
        }

        @font-face {
            font-family: "宋体";
        }

        @font-face {
            font-family: "Calibri";
        }

        @font-face {
            font-family: "SimSun";
        }

        @font-face {
            font-family: "Wingdings";
        }

        p.MsoNormal {
            mso-style-name: Normal;
            mso-style-parent: "";
            margin: 0pt;
            margin-bottom: .0001pt;
            font-family: Calibri;
            mso-fareast-font-family: SimSun;
            mso-bidi-font-family: 'Times New Roman';
        }

        span.10 {
            font-family: Calibri;
        }

        span.msoIns {
            mso-style-type: export-only;
            mso-style-name: "";
            text-decoration: underline;
            text-underline: single;
            color: blue;
        }

        span.msoDel {
            mso-style-type: export-only;
            mso-style-name: "";
            text-decoration: line-through;
            color: red;
        }

        table.MsoNormalTable {
            mso-style-name: "Table Normal";
            mso-style-parent: "";
            mso-style-noshow: yes;
            mso-tstyle-rowband-size: 0;
            mso-tstyle-colband-size: 0;
            mso-padding-alt: 0, 0000pt 5, 4000pt 0, 0000pt 5, 4000pt;
            mso-para-margin: 0pt;
            mso-para-margin-bottom: .0001pt;
            mso-pagination: widow-orphan;
            font-family: 'Times New Roman';
            font-size: 10, 0000pt;
            mso-ansi-language: #0400;
            mso-fareast-language: #0400;
            mso-bidi-language: #0400;
        }

        table.MsoTableGrid {
            mso-style-name: "Table Grid";
            mso-tstyle-rowband-size: 0;
            mso-tstyle-colband-size: 0;
            mso-padding-alt: 0, 0000pt 5, 4000pt 0, 0000pt 5, 4000pt;
            mso-border-top-alt: 0, 5000pt solid windowtext;
            mso-border-left-alt: 0, 5000pt solid windowtext;
            mso-border-bottom-alt: 0, 5000pt solid windowtext;
            mso-border-right-alt: 0, 5000pt solid windowtext;
            mso-border-insideh: 0, 5000pt solid windowtext;
            mso-border-insidev: 0, 5000pt solid windowtext;
            mso-para-margin: 0pt;
            mso-para-margin-bottom: .0001pt;
            mso-pagination: none;
            text-align: justify;
            text-justify: inter-ideograph;
            font-family: 'Times New Roman';
            font-size: 10, 0000pt;
            mso-ansi-language: #0400;
            mso-fareast-language: #0400;
            mso-bidi-language: #0400;
        }

        @page {
            mso-page-border-surround-header: no;
            mso-page-border-surround-footer: no;
        }

        @page Section0 {
            margin-top: 14, 1500pt;
            margin-bottom: 14, 1500pt;
            margin-left: 43, 6500pt;
            margin-right: 43, 6500pt;
            size: 839, 1500pt 592, 5000pt;
            layout-grid: 18, 0000pt;
            mso-page-orientation: landscape;
        }

        div.Section0 {
            page: Section0;
        }
    </style>

</head>

<body style="tab-interval:21pt;text-justify-trim:punctuation;">

    <!--StartFragment-->

    <!--StartFragment-->
    <div class="Section0" style="layout-grid:18,0000pt;">

        <table class=MsoTableGrid border=0 cellspacing=0 style="border-collapse:collapse;width:996,0000pt;margin-left:6,7500pt;margin-right:6,7500pt;mso-table-layout-alt:fixed;border:none;mso-border-insideh:0,5000pt solid windowtext;mso-padding-alt:0,0000pt 5,4000pt 0,0000pt 5,4000pt ;">

            <tr style="height:13,7000pt;">
                <td width=664 valign=top style="width:498,0000pt;padding:0,0000pt 5,4000pt 0,0000pt 5,4000pt ;border-left:none;border-right:none;border-top:none;border-bottom:none;">
                    <p class=MsoNormal align=justify style="mso-pagination:none;text-align:justify;text-justify:inter-ideograph;">
                        <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;">NUMBER: Un.07/<?= $mhs->no_ijazah ?></span>
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;">
                            <o:p></o:p>
                        </span>
                    </p>
                </td>
                <td id="tdi" align=justify style="text-align:center;">
                    <img src=" <?= base_url('assets/img/kop.png'); ?>" width="100" />

                </td>
                <td width=664 valign=top style="width:498,0000pt;padding:0,0000pt 5,4000pt 0,0000pt 5,4000pt ;border-left:none;border-right:none;border-top:none;border-bottom:none;">
                    <p class=MsoNormal align=right style="mso-pagination:none;text-align:right;">
                        <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;">NUMBER: FST/S1/0/2021</span>
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;">
                            <o:p></o:p>
                        </span>
                    </p>
                </td>
            </tr>
        </table>

        <p class=MsoNormal>
            <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;">
                <o:p>&nbsp;</o:p>
            </span>
        </p>

        <p class=MsoNormal>
            <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;">
                <o:p>&nbsp;</o:p>
            </span>
        </p>

        <p class=MsoNormal align=center style="text-align:center;">
            <b>
                <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;font-size:12,0000pt;">MINISTRY OF RELIGIOUS AFFAIRS</span>
            </b>
            <b>
                <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;font-size:12,0000pt;">
                    <o:p></o:p>
                </span></b>
        </p>
        <p class=MsoNormal align=center style="text-align:center;">
            <b>
                <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;font-size:12,0000pt;">STATE ISLAMIC UNIVERSITY</span>
            </b>
            <b>
                <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;font-size:12,0000pt;">
                    <o:p></o:p>
                </span>
            </b>
        </p>
        <p class=MsoNormal align=center style="text-align:center;">
            <b>
                <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;font-size:12,0000pt;">SUNAN GUNUNG DJATI BANDUNG</span></b>
            <b>
                <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;font-size:12,0000pt;">
                    <o:p></o:p>
                </span>
            </b>
        </p>
        <p class=MsoNormal align=center style="text-align:center;">
            <b>
                <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;">
                    <o:p>&nbsp;</o:p>
                </span>
            </b>
        </p>
        <p class=MsoNormal align=center style="text-align:center;line-height:150%;">
            <b>
                <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;">Herewith has declared that:</span>
            </b>
            <b>
                <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;">
                    <o:p></o:p>
                </span>
            </b>
        </p>
        <p class=MsoNormal align=center style="text-align:center;line-height:150%;">

            <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;
            font-weight:normal;font-size:10,5000pt;"><?= strtoupper($mhs->nama) ?></span>
            <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal align=center style="text-align:center;line-height:150%;">

            <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">STUDENT ID NUMBER : <?= $mhs->nim ?></span>
            <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal align=justify style="text-align:justify;text-justify:inter-ideograph;">
            <br>
            <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:12,5000pt;">Born in <?= $mhs->tempat_lahir ?>, <?= $mhs->tanggal_lahir ?>, has finished and fulfilled all the resquirement at Study Program of <?= $nama_jurusan ?>, therefore the University has conffered upon his the degree of :
                <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                    <o:p></o:p>
                </span>
        </p>
        <p class=MsoNormal align=center style="text-align:center;line-height:150%;">
            <b>
                <br>
                <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;font-size:16,0000pt;"><?= $gelar ?></span>
            </b>
            <b>
                <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;font-size:16,0000pt;">
                    <o:p></o:p>
                </span>
            </b>
        </p>
        <p class=MsoNormal align=justify style="text-align:justify;text-justify:inter-ideograph;line-height:150%;">
            <br>
            <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">Along with rights and obligations attached to the degree. </span>
            <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal align=justify style="text-align:justify;text-justify:inter-ideograph;line-height:150%;">
            <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">Given in Bandung, <?= $mhs->tanggal_ijazah ?>.</span>
            <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <table class=MsoTableGrid border=0 cellspacing=0 style="border-collapse:collapse;width:989,0000pt;mso-table-layout-alt:fixed;border:none;mso-padding-alt:0,0000pt 5,4000pt 0,0000pt 5,4000pt ;">
            <tr style="height:90,2500pt;">
                <td width=439 valign=top style="width:329,6000pt;padding:0,0000pt 5,4000pt 0,0000pt 5,4000pt ;border-left:none;border-right:none;border-top:none;border-bottom:none;">
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <br>
                        <br>
                        <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">DEAN,</span>
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p></o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">Faculty of Science and Technology</span>
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p></o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p>&nbsp;</o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p>&nbsp;</o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p>&nbsp;</o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <b>
                            <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;font-size:10,5000pt;">Dr. H. Opik Taupik Kurahman</span>
                        </b>
                        <b>
                            <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;font-size:10,5000pt;">
                                <o:p></o:p>
                            </span>
                        </b>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">NIP. 196812131996031001</span>
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p></o:p>
                        </span>
                    </p>
                </td>
                <td width=439 valign=top style="width:329,7000pt;padding:0,0000pt 5,4000pt 0,0000pt 5,4000pt ;border-left:none;border-right:none;border-top:none;border-bottom:none;">
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p>&nbsp;</o:p>
                        </span>
                    </p>
                </td>
                <td width=439 valign=top style="width:329,7000pt;padding:0,0000pt 5,4000pt 0,0000pt 5,4000pt ;border-left:none;border-right:none;border-top:none;border-bottom:none;">
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <br>
                        <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">Rector,</span>
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p></o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p>&nbsp;</o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p>&nbsp;</o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p>&nbsp;</o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p>&nbsp;</o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <b>
                            <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;font-size:10,5000pt;">Prof, Dr. H. Mahmud, M.Si.</span>
                        </b>
                        <b>
                            <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;font-size:10,5000pt;">
                                <o:p></o:p>
                            </span>
                        </b>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">NIP. 196204101988031001</span>
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p></o:p>
                        </span>
                    </p>
                </td>
            </tr>
            <tr style="height:135,4000pt;">
                <td width=439 valign=top style="width:329,6000pt;padding:0,0000pt 5,4000pt 0,0000pt 5,4000pt ;border-left:none;border-right:none;border-top:none;border-bottom:none;">
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p>&nbsp;</o:p>
                        </span>
                    </p>
                </td>
                <td width=439 valign=top style="width:329,7000pt;padding:0,0000pt 5,4000pt 0,0000pt 5,4000pt ;border-left:none;border-right:none;border-top:none;border-bottom:none;">
                        
                        <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">Date: <?= $mhs->tahun_lulus ?></span>
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p></o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <br>
                        <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">This is an authorized English Translation of the original diploma issued by Islamic State University Sunan Gunung</span>
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p></o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;line-height:150%;">
                        <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">Djati Bandung</span>
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p></o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">Faculty of Science and Technology</span>
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p></o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">Dean:</span>
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p></o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p>&nbsp;</o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p>&nbsp;</o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p>&nbsp;</o:p>
                        </span>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <b>
                            <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;font-size:10,5000pt;">Dr. H. Opik Taupik Kurahman</span>
                        </b>
                        <b>
                            <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;font-size:10,5000pt;">
                                <o:p></o:p>
                            </span>
                        </b>
                    </p>
                    <p class=MsoNormal align=center style="mso-pagination:none;text-align:center;">
                        <b>
                            <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;font-size:10,5000pt;">NIP. 196812131996031001</span>
                        </b>
                        <b>
                            <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:bold;font-size:10,5000pt;">
                                <o:p></o:p>
                            </span>
                        </b>
                    </p>
                </td>
                <td width=439 valign=top style="width:329,7000pt;padding:0,0000pt 5,4000pt 0,0000pt 5,4000pt ;border-left:none;border-right:none;border-top:none;border-bottom:none;">
                    <p class=MsoNormal align=justify style="mso-pagination:none;text-align:justify;text-justify:inter-ideograph;">
                        <span style="font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                            <o:p>&nbsp;</o:p>
                        </span>
                    </p>
                </td>
            </tr>
        </table>
        <p class=MsoNormal align=justify style="text-align:justify;text-justify:inter-ideograph;line-height:150%;">
            <span style="mso-spacerun:'yes';font-family:'Times New Roman';mso-fareast-font-family:SimSun;font-weight:normal;font-size:10,5000pt;">
                <o:p>&nbsp;</o:p>
            </span>
        </p>
    </div>
    <script>
        window.print();
    </script>
</body>

</html>