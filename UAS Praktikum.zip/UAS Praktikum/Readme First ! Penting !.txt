UAS Praktikum Rekayasa Perangkat Lunak
Aplikasi Penerjemahan Ijazah

Andri Kurnianto        (1167050026)
Fahmi Fauzi Kadarmanto (1177050127)

Link Youtube : https://www.youtube.com/watch?v=f62Kx1trlwM

Aplikasi ini menggunakan MySQL (localhost). Import databasenya di dalam folder prpl. File databasenya bernama prpl(4).sql